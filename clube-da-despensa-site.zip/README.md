# Clube da Despensa — Site (Vite + React + Tailwind)
Siga o passo a passo na conversa para publicar via Vercel. Edite `src/App.jsx` (bloco CONFIG) para seu número de WhatsApp.
